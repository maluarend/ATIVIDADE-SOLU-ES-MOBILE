# Filmes App (React Native + Expo)

App que consome a API OMDb (busca "spider man"), lista os filmes na tela principal e mostra os detalhes em uma segunda tela.

**Tecnologias:** React Native, Expo, React Navigation (Native Stack), React Native Paper, API REST (fetch).

## Como rodar
```bash
npm install
npx expo install --fix   # alinha as versões com o SDK do Expo instalado
npx expo start
```
Abra no celular com o app **Expo Go** (QR Code) ou use `a` (Android) / `w` (web).

## Estrutura
- `App.js` – PaperProvider + NavigationContainer + Stack
- `src/api.js` – chamadas REST
- `src/screens/HomeScreen.js` – lista de filmes
- `src/screens/DetailsScreen.js` – detalhes do filme
