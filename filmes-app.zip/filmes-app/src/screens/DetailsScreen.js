import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { ActivityIndicator, Button, Card, Chip, Text } from 'react-native-paper';
import { buscarDetalhes } from '../api';

export default function DetailsScreen({ route, navigation }) {
  const { imdbID } = route.params;
  const [filme, setFilme] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        setFilme(await buscarDetalhes(imdbID));
      } catch (e) {
        setErro(e.message);
      } finally {
        setCarregando(false);
      }
    })();
  }, [imdbID]);

  if (carregando) {
    return (
      <View style={styles.centro}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (erro) {
    return (
      <View style={styles.centro}>
        <Text>Ops! {erro}</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Card>
        {filme.Poster && filme.Poster !== 'N/A' && (
          <Card.Cover source={{ uri: filme.Poster }} style={styles.capa} resizeMode="contain" />
        )}
        <Card.Title title={filme.Title} subtitle={`${filme.Year} • ${filme.Runtime} • ${filme.Rated}`} />
        <Card.Content>
          <View style={styles.chips}>
            {filme.Genre?.split(', ').map((g) => (
              <Chip key={g} style={styles.chip}>{g}</Chip>
            ))}
          </View>
          <Text variant="titleSmall" style={styles.rotulo}>Sinopse</Text>
          <Text variant="bodyMedium">{filme.Plot}</Text>
          <Text variant="titleSmall" style={styles.rotulo}>Diretor</Text>
          <Text variant="bodyMedium">{filme.Director}</Text>
          <Text variant="titleSmall" style={styles.rotulo}>Elenco</Text>
          <Text variant="bodyMedium">{filme.Actors}</Text>
          <Text variant="titleSmall" style={styles.rotulo}>Nota IMDb</Text>
          <Text variant="bodyMedium">{filme.imdbRating} / 10</Text>
        </Card.Content>
        <Card.Actions>
          <Button onPress={() => navigation.goBack()}>Voltar</Button>
        </Card.Actions>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  centro: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  container: { padding: 12 },
  capa: { height: 400, backgroundColor: '#eee' },
  chips: { flexDirection: 'row', flexWrap: 'wrap', marginVertical: 8 },
  chip: { marginRight: 6, marginBottom: 6 },
  rotulo: { marginTop: 12, fontWeight: 'bold' },
});
