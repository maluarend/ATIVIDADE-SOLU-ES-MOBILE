import React, { useEffect, useState } from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import { ActivityIndicator, Button, Card, Text } from 'react-native-paper';
import { buscarFilmes } from '../api';

export default function HomeScreen({ navigation }) {
  const [filmes, setFilmes] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState(null);

  async function carregar() {
    setCarregando(true);
    setErro(null);
    try {
      setFilmes(await buscarFilmes('spider man'));
    } catch (e) {
      setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  if (carregando) {
    return (
      <View style={styles.centro}>
        <ActivityIndicator size="large" />
        <Text style={styles.espaco}>Carregando filmes...</Text>
      </View>
    );
  }

  if (erro) {
    return (
      <View style={styles.centro}>
        <Text variant="titleMedium">Ops! {erro}</Text>
        <Button mode="contained" onPress={carregar} style={styles.espaco}>
          Tentar novamente
        </Button>
      </View>
    );
  }

  return (
    <FlatList
      data={filmes}
      keyExtractor={(item) => item.imdbID}
      contentContainerStyle={styles.lista}
      renderItem={({ item }) => (
        <Card style={styles.card} onPress={() => navigation.navigate('Details', { imdbID: item.imdbID, titulo: item.Title })}>
          <View style={styles.linha}>
            {item.Poster && item.Poster !== 'N/A' ? (
              <Card.Cover source={{ uri: item.Poster }} style={styles.poster} />
            ) : (
              <View style={[styles.poster, styles.semPoster]}>
                <Text>Sem pôster</Text>
              </View>
            )}
            <Card.Content style={styles.info}>
              <Text variant="titleMedium" numberOfLines={2}>{item.Title}</Text>
              <Text variant="bodyMedium">Ano: {item.Year}</Text>
              <Text variant="bodySmall" style={styles.tipo}>{item.Type}</Text>
            </Card.Content>
          </View>
        </Card>
      )}
    />
  );
}

const styles = StyleSheet.create({
  centro: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 16 },
  espaco: { marginTop: 12 },
  lista: { padding: 12 },
  card: { marginBottom: 12 },
  linha: { flexDirection: 'row' },
  poster: { width: 100, height: 150 },
  semPoster: { justifyContent: 'center', alignItems: 'center', backgroundColor: '#ddd' },
  info: { flex: 1, justifyContent: 'center' },
  tipo: { textTransform: 'capitalize', opacity: 0.7 },
});
