const BASE_URL = 'https://www.omdbapi.com/';
const API_KEY = '1cd66749';

export async function buscarFilmes(termo = 'spider man') {
  const url = `${BASE_URL}?s=${encodeURIComponent(termo)}&apikey=${API_KEY}`;
  const resposta = await fetch(url);
  if (!resposta.ok) throw new Error(`Erro HTTP ${resposta.status}`);
  const dados = await resposta.json();
  if (dados.Response === 'False') throw new Error(dados.Error || 'Nenhum filme encontrado');
  return dados.Search;
}

export async function buscarDetalhes(imdbID) {
  const url = `${BASE_URL}?i=${imdbID}&plot=full&apikey=${API_KEY}`;
  const resposta = await fetch(url);
  if (!resposta.ok) throw new Error(`Erro HTTP ${resposta.status}`);
  const dados = await resposta.json();
  if (dados.Response === 'False') throw new Error(dados.Error || 'Filme não encontrado');
  return dados;
}
